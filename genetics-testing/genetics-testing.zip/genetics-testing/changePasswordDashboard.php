<?php 
include 'connection.php';
$contact = $_POST['number'];
$email   = $_POST['email'];
$otp = rand(1111, 9999);

date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$date = date('d-m-Y');
$time =  date('H:i:s');

if (isset($contact) && isset($email)) {
    $insertQry = "INSERT INTO `changepassword` (`id`, `mobile`, `email`, `OTP`, `date`, `time`) VALUES (NULL, '$contact', '$email', '$otp', '$date', '$time')";
    $runQery = mysqli_query($conn ,$insertQry);
    if ($runQery) {
        echo "otp inserted and sent";
    }else {
         echo  0;
    }
}else {
    echo "values not set";
}

?>