<?php 
include 'connection.php';
 
$otp = $_POST['otp'];
$email = $_POST['useremail'];
$phone =$_POST['usernumber'];
$newPass = $_POST['newPassword'];

if (!empty($otp) && !empty($email) && !empty($phone) && !empty($newPass)) {
    $CheckOtp = "SELECT * FROM `changepassword` WHERE OTP = '$otp'";
    $runQuery = mysqli_query($conn,$CheckOtp);
    $countRows = mysqli_num_rows($runQuery);
    if ($countRows>0) {
        $updatePassword = "UPDATE `users` SET `password` = '$newPass' WHERE `users`.`email` = '$email'";
        $runQuery = mysqli_query($conn,$updatePassword);
        if ($runQuery) {
            $removeOtp = " UPDATE `changepassword` SET `OTP`=' ' WHERE OTP='$otp'";
              $runQuery=mysqli_query($conn,$removeOtp);
            if ($runQuery) {
                echo 1;
            }
             
        }
    }else {
         echo  0;
    }
}else {
     echo "no value entered";
}
?>