<?php 
include 'connection.php';
 
$otp = $_POST['otp'];
$email = $_POST['useremail'];
$phone =$_POST['usernumber'];
$newPass = $_POST['newPassword'];

if (!empty($otp) && !empty($email) && !empty($phone) && !empty($newPass)) {
    $CheckOtp = "select * from changepassword ORDER by id DESC limit 01";
    $runQuery = mysqli_query($conn,$CheckOtp);
    $countdata = mysqli_fetch_assoc($runQuery);
    $dbOtp = $countdata['OTP'];
    if ($otp==$dbOtp) {
        $updatePassword = "UPDATE `users` SET `password` = '$newPass' WHERE `users`.`email` = '$email'";
        $runQuery = mysqli_query($conn,$updatePassword);
        if ($runQuery) {
       echo 1;
            }
    }else {
         echo  0;
    }
}else {
     echo "no value entered";
}
?>