 <?php 
 
 $conn = mysqli_connect("localhost", "root" , "" , "youturn_genetics");
 if ($conn) {
      
 } 
 else { ?><script>alert("failed");</script><?php } ?>