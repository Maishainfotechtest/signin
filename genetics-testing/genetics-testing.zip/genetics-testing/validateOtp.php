<?php
include "connection.php";
$userOtp = $_POST['userOtp'];
$usernumber = $_POST['contact'];
if (!empty($userOtp)) {
    $checkOtp = "SELECT * FROM `usertemptable` order by `id` desc LIMIT 01";
    $runQry = mysqli_query($conn, $checkOtp);
    $countdata = mysqli_fetch_assoc($runQry);

    $bdOtp = $countdata['OTP'];
    if ($userOtp == $bdOtp) {
        $updateUser = "UPDATE `users` SET `mobile_verify`='yes'  WHERE mobile ='$usernumber'";
        $runQry = mysqli_query($conn, $updateUser);
        if ($runQry) {

            echo 1;
        }
    } else {
        echo  0;
    }
} else {
    echo 21;
}
