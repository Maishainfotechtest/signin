 <?php 
 session_start();
include('config.php');
//Destroy entire session data.
session_destroy();

//redirect page to index.php
 ?>
    <script>
    window.location.replace("http://localhost/genetics-testing/");
    </script>
    