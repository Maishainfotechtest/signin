<?php 
include 'connection.php';
$concode = $_POST['conId'];

if(!empty($concode)){
    $selConName = "SELECT * FROM `countries` WHERE phonecode='$concode'";
    $runQuery = mysqli_query($conn,$selConName);
    $data = mysqli_fetch_assoc($runQuery);
    $name = $data['name'];
    if (!empty($name)) {
       echo '<option value="'.$data['phonecode'].'" key="'.$data['id'].'">'."$name".'</option>';
       
    }
}else {
     echo "no name";
}
?>