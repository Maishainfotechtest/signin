<?php
include 'connection.php';
$email = $_POST['email'];
$resend = $_POST['resend'];
$otp = rand(1111, 9999);
if (!empty($resend)) {
    $updateOtp = "update `changepassword` set OTP = '$otp' where  email ='$email'";
    $runQry = mysqli_query($conn, $updateOtp);
    if ($runQry) {
        echo 1;
    } else {
        echo "OTP not updated ";
    }
}
