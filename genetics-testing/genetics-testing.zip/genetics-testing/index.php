﻿<?php include('includes/header.php');
include "connection.php";
include 'config.php';
// login with google
if (isset($_GET["code"])) {

  $token = $google_client->fetchAccessTokenWithAuthCode($_GET["code"]);


  if (!isset($token['error'])) {

    $google_client->setAccessToken($token['access_token']);


    $_SESSION['access_token'] = $token['access_token'];


    $google_service = new Google_Service_Oauth2($google_client);


    $data = $google_service->userinfo->get();

    if (!empty($data['id'])) {
      $_SESSION['id'] = $data['id'];
    }

    if (!empty($data['given_name'])) {
      $_SESSION['user_first_name'] = $data['given_name'];
    }

    if (!empty($data['family_name'])) {
      $_SESSION['user_last_name'] = $data['family_name'];
    }

    if (!empty($data['email'])) {
      $_SESSION['user_email'] = $data['email'];
    }

    if (!empty($data['gender'])) {
      $_SESSION['user_gender'] = $data['gender'];
    }

    if (!empty($data['picture'])) {
      $_SESSION['user_image'] = $data['picture'];
    }

    $name = $_SESSION['user_first_name'];
    $lname = $_SESSION['user_last_name'];
    $email = $_SESSION['user_email'];
    $CID = "Gog" . $_SESSION['id'];

    $joindate = date('Y:m:d');
    $jointime = date("h:i:s");
    date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
    $datetime = date('d-m-Y H:i:s');
    $CheckEmail = "SELECT * FROM users where email = '$email'";
    $runqry = mysqli_query($conn, $CheckEmail);
    $fbrow = mysqli_num_rows($runqry);
    $fbdata = mysqli_fetch_array($runqry);

    if ($fbrow == 1) {
      $_SESSION['username'] = $fbdata['f_name'];
      ?>
         <script>
                window.location.replace("http://localhost/genetics-testing/dashboard.php");
            </script>
        <?php
    } else {
     
      $insqry = "INSERT INTO `users` ( `id` ,`cid`, `f_name`, `l_name`, `email`, `email_verify`, `countrycode`, `mobile`, `mobile_verify`, `DOB`, `password`, `joindate`, `jointime`, `datetime`,`status`) VALUES ( NULL , '$CID', '$name', '$lname', '$email', 'yes', NULL, NULL, NULL, NULL, NULL, '$joindate', '$jointime', '$datetime', 'active')";
     //inserting data in userimage table
      $insertImage = "INSERT INTO `userimages` (`id`, `name`, `imgSrc`, `email`) VALUES (NULL, '$name', '', '$email')";
      $imgrun = mysqli_query($conn,$insertImage);
      $run = mysqli_query($conn, $insqry);
      if ($run) {
        $_SESSION['username'] = $name;
?>
        <script>
          window.location.replace("http://localhost/genetics-testing/dashboard.php");
        </script>
      <?php

      } else { ?>
        <!-- fURTHER CODE GOES HERE -->
<?php }
    }
  }
}
?>

<div id="rev_slider_5_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container slide-overlay" data-alias="classic4export" data-source="gallery">
  <!-- START REVOLUTION SLIDER -->
  <div id="rev_slider_5_1" class="rev_slider fullwidthabanner" data-version="5.4.8">
    <ul>

      <!-- SLIDE  -->
      <li data-index="rs-6" data-transition="slotzoom-horizontal" data-slotamount="1" data-easein="default" data-easeout="default" data-masterspeed="1500" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

        <!-- MAIN IMAGE -->

        <img src="images/slides/banner1.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina="">

        <!-- LAYERS -->

        <!-- LAYER NR. 1 -->
        <div class="tp-caption tp-resizeme" id="slide-7-layer-3" data-x="['left','left','left','left']" data-hoffset="['80','40','30','20']" data-y="['middle','middle','middle','middle']" data-voffset="['-95','-95','-60','-42']" data-fontsize="['55','60','60','40']" data-lineheight="['70','70','70','40']" data-fontweight="['700','700','700','700']" data-color="#031b4e" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:1000;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;" data-start="900" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-type="text" data-responsive_offset="on" style="z-index:13;font-family:Poppins,sans-serif;">Build a tree <span class="ttm-textcolor-skincolor"> & magnify</span>
        </div>


        <!-- LAYER NR. 2 -->
        <div class="tp-caption tp-resizeme" id="slide-7-layer-2" data-x="['left','left','left','left']" data-hoffset="['80','40','30','20']" data-y="['middle','middle','middle','middle']" data-voffset="['-25','-25','20','7']" data-fontsize="['55','60','60','40']" data-lineheight="['70','70','70','40']" data-fontweight="['700','700','700','700']" data-color="#031b4e" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:1000;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;" data-start="900" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-type="text" data-responsive_offset="on" style="z-index:13;font-family:Poppins,sans-serif;margin-top:50px;"> your DNA results
        </div>

        <!-- LAYER NR. 3 -->


        <!-- LAYER NR. 4 -->
        <a class="tp-caption ttm-btn ttm-btn-shape-rounded buy-btn ttm-btn-color-skincolor" href="about-us.php" target="_self" id="slide-7-layer-5" data-x="['left','left','left','left']" data-hoffset="['80','40','30','20']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['140','160','105','60']" data-fontsize="['15','15','15','14']" data-lineheight="['20','20','16','15']" data-fontweight="['700','700','700','700']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:1000;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;" data-start="1500" data-splitin="none" data-splitout="none" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[14,14,11,11]" data-paddingright="[35,35,30,30]" data-paddingbottom="[13,13,10,10]" data-paddingleft="[35,35,30,30]" data-type="button" data-responsive_offset="on">Learn More
        </a>




      </li>

      <li data-index="rs-7" data-transition="slotzoom-horizontal" data-slotamount="1" data-easein="default" data-easeout="default" data-masterspeed="1500" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

        <!-- MAIN IMAGE -->

        <img src="images/slides/banner2.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina="">

        <!-- LAYERS -->

        <!-- LAYER NR. 3 -->
        <div class="tp-caption tp-resizeme" id="slide-7-layer-3" data-x="['left','left','left','left']" data-hoffset="['80','40','30','20']" data-y="['middle','middle','middle','middle']" data-voffset="['-95','-95','-60','-42']" data-fontsize="['55','60','60','40']" data-lineheight="['70','70','70','40']" data-fontweight="['700','700','700','700']" data-color="#031b4e" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:1000;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;" data-start="900" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-type="text" data-responsive_offset="on" style="z-index:13;font-family:Poppins,sans-serif;">One family name can
        </div>


        <!-- LAYER NR. 2 -->
        <div class="tp-caption tp-resizeme" id="slide-7-layer-2" data-x="['left','left','left','left']" data-hoffset="['80','40','30','20']" data-y="['middle','middle','middle','middle']" data-voffset="['-25','-25','20','7']" data-fontsize="['55','60','60','40']" data-lineheight="['70','70','70','40']" data-fontweight="['700','700','700','700']" data-color="#031b4e" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:1000;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;" data-start="900" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-type="text" data-responsive_offset="on" style="z-index:13;font-family:Poppins,sans-serif;margin-top:50px;"> lead many<span class="ttm-textcolor-skincolor"> discoveries</span>
        </div>


        <!-- LAYER NR. 4 -->


        <!-- LAYER NR. 5 -->
        <a class="tp-caption ttm-btn ttm-btn-shape-rounded buy-btn ttm-btn-color-skincolor" href="about-us.php" target="_self" id="slide-7-layer-5" data-x="['left','left','left','left']" data-hoffset="['80','40','30','20']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['140','160','105','60']" data-fontsize="['15','15','15','14']" data-lineheight="['20','20','16','15']" data-fontweight="['700','700','700','700']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:1000;e:Power2.easeOut;" data-transform_out="opacity:0;s:1000;e:Power4.easeIn;" data-start="1500" data-splitin="none" data-splitout="none" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[14,14,11,11]" data-paddingright="[35,35,30,30]" data-paddingbottom="[13,13,10,10]" data-paddingleft="[35,35,30,30]" data-type="button" data-responsive_offset="on">Learn more
        </a>

      </li>

    </ul>
    <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
  </div>
</div>
<!-- END REVOLUTION SLIDER -->

<!--site-main start-->
<div class="site-main">

  <!--introduction-section-->
  <section class="ttm-row introduction-section clearfix">
    <div class="container">
      <div class="row no-gutters">
        <div class="col-xl-6 col-lg-5 col-xs-12">
          <!-- ttm_single_image-wrapper -->
          <div class="ttm_single_image-wrapper mb-30"> <img class="img-fluid" src="images/dna.jpg" alt=""> </div>
        </div>
        
        <div class="col-xl-6 col-lg-7 col-xs-12">
          <div class="pt-5 res-991-pt-0">
            <!-- section title -->
            <div class="section-title">
              <div class="title-header">
                <h5>Overview</h5>
                <h2 class="title">About DNA</h2>

              </div>
              <div class="title-desc">Genetic testing involves examining your DNA, the chemical database that carries instructions for your body's functions. Genetic testing can reveal changes (mutations) in your genes that may cause illness or disease.</div>
              <div class="title-desc">Although genetic testing can provide important information for diagnosing, treating and preventing illness, there are limitations. For example, if you're a healthy person, a positive result from genetic testing doesn't always mean you will develop a disease. On the other hand, in some situations, a negative result doesn't guarantee that you won't have a certain disorder.</div>
              <div class="title-desc">Talking to your doctor, a medical geneticist or a genetic counselor about what you will do with the results is an important step in the process of genetic testing.</div>
            </div>
            <!-- section title end -->
            <div class="featuredbox-number">
              <!--featured-icon-box-->
              <div class="featured-icon-box icon-align-before-content style2">
                <div class="featured-icon">
                  <div class="ttm-icon ttm-icon_element-fill ttm-icon_element-color-grey ttm-icon_element-size-sm ttm-icon_element-style-rounded"> <i class="ttm-num ti-info"></i> </div>
                </div>
                <div class="featured-content">
                  <div class="featured-title">
                    <h5>Genome sequencing</h5>
                  </div>
                  <div class="featured-desc">
                    <p>When genetic testing doesn't lead to a diagnosis but a genetic cause is still suspected, some facilities offer genome sequencing — a process for analyzing a sample of DNA taken from your blood.</p>
                    <p>Everyone has a unique genome, made up of the DNA in all of a person's genes. This complex testing can help identify genetic variants that may relate to your health. This testing is usually limited to just looking at the protein-encoding parts of DNA called the exome.</p>
                  </div>
                </div>
              </div>
              <!-- featured-icon-box end-->

            </div>
          </div>
        </div>
      </div>
      <!-- row end -->
      <div class="row ttm-boxes-spacing-5px mt-20">
        <div class="col-lg-4 col-md-6 col-sm-6 ttm-box-col-wrapper">
          <!-- ttm-fid -->
          <div class="ttm-fid inside ttm-fid-with-icon ttm-fid-view-lefticon style1">
            <div class="ttm-fid-icon-wrapper"> <i class="ti ti-cup"></i> </div>
            <div class="ttm-fid-contents">
              <h4 class="ttm-fid-inner"> <span data-appear-animation="animateDigits" data-from="0" data-to="76" data-interval="15" data-before="" data-before-style="sup" data-after="" data-after-style="sub" class="numinate">76 </span> <sub>+</sub> </h4>
              <h3 class="ttm-fid-title">making healthier
                choices</h3>
            </div>
          </div>
          <!-- ttm-fid end -->
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 ttm-box-col-wrapper">
          <!-- ttm-fid -->
          <div class="ttm-fid inside ttm-fid-with-icon ttm-fid-view-lefticon style1">
            <div class="ttm-fid-icon-wrapper"> <i class="flaticon-healthcare-and-medical-1"></i> </div>
            <div class="ttm-fid-contents">
              <h4 class="ttm-fid-inner"> <span data-appear-animation="animateDigits" data-from="0" data-to="780" data-interval="15" data-before="" data-before-style="sup" data-after="" data-after-style="sub" class="numinate">55 </span> <sub>+</sub> </h4>
              <h3 class="ttm-fid-title">eating a healthier
                diet</h3>
            </div>
          </div>
          <!-- ttm-fid end -->
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 ttm-box-col-wrapper">
          <!-- ttm-fid -->
          <div class="ttm-fid inside ttm-fid-with-icon ttm-fid-view-lefticon style1">
            <div class="ttm-fid-icon-wrapper"> <i class="flaticon-magnifier"></i> </div>
            <div class="ttm-fid-contents">
              <h4 class="ttm-fid-inner"> <span data-appear-animation="animateDigits" data-from="0" data-to="675" data-interval="15" data-before="" data-before-style="sup" data-after="" data-after-style="sub" class="numinate">51 </span> <sub>+</sub> </h4>
              <h3 class="ttm-fid-title">setting healthy
                goals</h3>
            </div>
          </div>
          <!-- ttm-fid end -->
        </div>
      </div>
    </div>
  </section>
  <!--introduction-section end-->

  <!--features-section-->
  <section class="ttm-row pricing-plan-section-2 clearfix" style="background:#fff;">
    <div class="container">
      <!-- row -->
      <div class="row">
        <div class="col-md-4">
          <!--ttm-pricing-plan-->
          <div class="ttm-pricing-plan">
            <div class="ttm-p_table-head">
              <div class="ttm-p_table-title">
                <h3><img src="images/genetic-kit.png" class="img-fluid"></h3>
              </div>
              <h5>Package 1</h5>
            </div>
            <div class="ttm-p_table-body">
              <div class="ttm-p_table-amount"> <span class="cur_symbol">$</span>XXX Sale<span class="pac_frequency">Price:$XXX</span> </div>
              <ul class="ttm-p_table-features">
                <li>If you want the most comprehensive ancestry breakdown on the market.</li>
                <li>2000+ Geographic regions</li>
                <li>Automatic Family Tree Builder</li>
                <li>30+ Trait reports</li>
                <li>DNA Relative Finder</li>
              </ul>
            </div>
            <br>
            <a class="ttm-btn buy-btn ttm-btn-size-sm ttm-btn-shape-round ttm-icon-btn-right ttm-btn-color-skincolor" href="cart.php" title="">Buy Now <i class="ti ti-arrow-circle-right"></i></a>
          </div>
          <!--ttm-pricing-plan-->
        </div>
        <div class="col-md-4">
          <!--ttm-pricing-plan-->
          <div class="ttm-pricing-plan">
            <div class="ttm-p_table-head">
              <div class="ttm-p_table-title">
                <h3><img src="images/genetic-kit.png" class="img-fluid"></h3>
              </div>
              <h5>Package 2</h5>
            </div>
            <div class="ttm-p_table-body">
              <div class="ttm-p_table-amount"> <span class="cur_symbol">$</span>XXX Sale<span class="pac_frequency">Price:$XXX</span> </div>
              <ul class="ttm-p_table-features">
                <li>If you want the most comprehensive ancestry breakdown on the market.</li>
                <li>2000+ Geographic regions</li>
                <li>Automatic Family Tree Builder</li>
                <li>30+ Trait reports</li>
                <li>DNA Relative Finder</li>
              </ul>
            </div>
            <br>
            <a class="ttm-btn buy-btn ttm-btn-size-sm ttm-btn-shape-round ttm-icon-btn-right ttm-btn-color-skincolor" href="cart.php" title="">Buy Now <i class="ti ti-arrow-circle-right"></i></a>
          </div>
          <!--ttm-pricing-plan-->
        </div>
        <div class="col-md-4">
          <!--ttm-pricing-plan-->
          <div class="ttm-pricing-plan">
            <div class="ttm-p_table-head">
              <div class="ttm-p_table-title">
                <h3><img src="images/genetic-kit.png" class="img-fluid"></h3>
              </div>
              <h5>Package 3</h5>
            </div>
            <div class="ttm-p_table-body">
              <div class="ttm-p_table-amount"> <span class="cur_symbol">$</span>XXX Sale<span class="pac_frequency">Price:$XXX</span> </div>
              <ul class="ttm-p_table-features">
                <li>If you want the most comprehensive ancestry breakdown on the market.</li>
                <li>2000+ Geographic regions</li>
                <li>Automatic Family Tree Builder</li>
                <li>30+ Trait reports</li>
                <li>DNA Relative Finder</li>
              </ul>
            </div>
            <br>
            <a class="ttm-btn buy-btn ttm-btn-size-sm ttm-btn-shape-round ttm-icon-btn-right ttm-btn-color-skincolor" href="cart.php" title="">Buy Now <i class="ti ti-arrow-circle-right"></i></a>
          </div>
          <!--ttm-pricing-plan-->
        </div>
      </div>
      <!-- row end -->
    </div>
  </section>
  <!--features-section end-->

  <!--services-section-->
  <section class="ttm-row services-section ttm-bgcolor-grey bg-img5 ttm-bg ttm-bgimage-yes clearfix">
    <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
    <div class="container">
      <!-- row -->
      <div class="row">
        <div class="col-lg-6 col-md-8 col-sm-10 m-auto">
          <!-- section-title -->
          <div class="section-title with-sep title-style-center_text">
            <div class="title-header">
              <h2 class="title">Why it's done</h2>
            </div>
            <div class="title-desc">Genetic testing plays a vital role in determining the risk of developing certain diseases as well as screening and sometimes medical treatment. Different types of genetic testing are done for different reasons:</div>
          </div>
          <!-- section-title end -->
        </div>
      </div>
      <!-- row end -->
      <div class="row">
        <div class="col-lg-12">
          <div class="service-box">
            <div class="row align-items-center no-gutters">
              <div class="col-xl-7 col-lg-6">
                <div class="mt_5 pb-30">
                  <h4>Diagnostic testing</h4>
                  <p class="pb-10">If you have symptoms of a disease that may be caused by genetic changes, sometimes called mutated genes, genetic testing can reveal if you have the suspected disorder. For example, genetic testing may be used to confirm a diagnosis of cystic fibrosis or Huntington's disease.</p>
                  <h4>Presymptomatic and predictive testing</h4>
                  <p class="pb-10">If you have a family history of a genetic condition, getting genetic testing before you have symptoms may show if you're at risk of developing that condition. For example, this type of test may be useful for identifying your risk of certain types of colorectal cancer.</p>
                  <h4>Pharmacogenetics</h4>
                  <p class="pb-10">If you have a particular health condition or disease, this type of genetic testing may help determine what medication and dosage will be most effective and beneficial for you.</p>
                </div>
              </div>
              <div class="col-xl-5 col-lg-6">
                <!-- ttm_single_image-wrapper -->
                <div class="ttm_single_image-wrapper text-right pb-30"> <img class="img-fluid" src="images\testing1.jpg" style="border-radius: 10px;" alt=""> </div>
              </div>
            </div>
            <div class="row align-items-center no-gutters">
              <div class="col-xl-5 col-lg-6">
                <!-- ttm_single_image-wrapper -->
                <div class="ttm_single_image-wrapper"> <img class="img-fluid" src="images\testing2.jpg" alt=""> </div>
              </div>
              <div class="col-xl-7 col-lg-6">
                <div class="mt_5 ml_20 res-991-ml-0 res-991-pt-30 res-991-pb-15">
                  <h4>Carrier testing</h4>
                  <p class="pb-10">If you have a family history of a genetic disorder — such as sickle cell anemia or cystic fibrosis — or you're in an ethnic group that has a high risk of a specific genetic disorder, you may choose to have genetic testing before having children. An expanded carrier screening test can detect genes associated with a wide variety of genetic diseases and mutations and can identify if you and your partner are carriers for the same conditions.</p>
                  <h4>Prenatal testing</h4>
                  <p class="pb-10">If you're pregnant, tests can detect some types of abnormalities in your baby's genes. Down syndrome and trisomy 18 syndrome are two genetic disorders that are often screened for as part of prenatal genetic testing. Traditionally this is done looking at markers in blood or by invasive testing such as amniocentesis. Newer testing called cell-free DNA testing looks at a baby's DNA via a blood test done on the mother.</p>
                </div>
              </div>
            </div>
            <div class="row align-items-center no-gutters">
              <div class="col-xl-7 col-lg-6">
                <div class="mt_5 pb-30">
                  <h4>Newborn screening</h4>
                  <p class="pb-10">This is the most common type of genetic testing. In the United States, all states require that newborns be tested for certain genetic and metabolic abnormalities that cause specific conditions. This type of genetic testing is important because if results show there's a disorder such as congenital hypothyroidism, sickle cell disease or phenylketonuria (PKU), care and treatment can begin right away.</p>
                  <h4>Preimplantation testing</h4>
                  <p class="pb-10">Also called preimplantation genetic diagnosis, this test may be used when you attempt to conceive a child through in vitro fertilization. The embryos are screened for genetic abnormalities. Embryos without abnormalities are implanted in the uterus in hopes of achieving pregnancy</p>
                </div>
              </div>
              <div class="col-xl-5 col-lg-6">
                <!-- ttm_single_image-wrapper -->
                <div class="ttm_single_image-wrapper text-right pb-30"> <img class="img-fluid" src="images\testing3.jpg" style="border-radius: 10px;" alt=""> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--services-section-->

  <!--technology-section-->
  <section class="ttm-row technology-section bg-img7 bg-layer z-index_1 clearfix">
    <div class="container">
      <!-- row -->
      <div class="row">
        <div class="col-lg-9 col-md-12 ml-auto">
          <div class="ttm-bg ttm-col-bgcolor-yes ttm-bgcolor-white spacing-7">
            <div class="ttm-col-wrapper-bg-layer ttm-bg-layer"></div>
            <div class="layer-content">
              <!-- section title -->
              <div class="section-title">
                <div class="title-header">
                  <h5>More Information</h5>
                  <h2 class="title">Genetic testing</h2>
                </div>
              </div>
              <!-- section title end -->
              <div class="accordion clearfix">
                <!-- toggle -->
                <div class="toggle ttm-style-classic ttm-toggle-title-bgcolor-grey ttm-control-right-true">
                  <div class="toggle-title"><a href="#">Risks</a></div>
                  <div class="toggle-content">
                    <div class="d-sm-flex align-items-center">
                      <div class="toggle-text res-575-ml-0 res-575-mt-10">Generally genetic tests have little physical risk. Blood and cheek swab tests have almost no risk. However, prenatal testing such as amniocentesis or chorionic villus sampling has a small risk of pregnancy loss (miscarriage).<br>
                        Genetic testing can have emotional, social and financial risks as well. Discuss all risks and benefits of genetic testing with your doctor, a medical geneticist or a genetic counselor before you have a genetic test. </div>
                    </div>
                  </div>
                </div>
                <!-- toggle end -->
                <!-- toggle -->
                <div class="toggle ttm-style-classic ttm-toggle-title-bgcolor-grey ttm-control-right-true">
                  <div class="toggle-title"><a href="#">How you prepare</a></div>
                  <div class="toggle-content">
                    <div class="d-sm-flex align-items-center">
                      <div class="toggle-text res-575-ml-0 res-575-mt-10">Before you have genetic testing, gather as much information as you can about your family's medical history. Then, talk with your doctor or a genetic counselor about your personal and family medical history to better understand your risk. Ask questions and discuss any concerns about genetic testing at that meeting. Also, talk about your options, depending on the test results.<br>
                        If you're being tested for a genetic disorder that runs in families, you may want to consider discussing your decision to have genetic testing with your family. Having these conversations before testing can give you a sense of how your family might respond to your test results and how it may affect them.<br>
                        Not all health insurance policies pay for genetic testing. So, before you have a genetic test, check with your insurance provider to see what will be covered.<br>
                        In the United States, the federal Genetic Information Nondiscrimination Act of 2008 (GINA) helps prevent health insurers or employers from discriminating against you based on test results. Under GINA, employment discrimination based on genetic risk also is illegal. However, this act does not cover life, long-term care or disability insurance. Most states offer additional protection.</div>
                    </div>
                  </div>
                </div>
                <!-- toggle end -->
                <!-- toggle -->
                <div class="toggle ttm-style-classic ttm-toggle-title-bgcolor-grey ttm-control-right-true">
                  <div class="toggle-title"><a href="#">What you can expect</a></div>
                  <div class="toggle-content">
                    <div class="d-sm-flex align-items-center">
                      <div class="toggle-text res-575-ml-0 res-575-mt-10">Depending on the type of test, a sample of your blood, skin, amniotic fluid or other tissue will be collected and sent to a lab for analysis.
                        <ul class="ttm-list ttm-list-style-icon">
                          <li><i class="fa fa-minus"></i>
                            <div class="ttm-list-li-content"><strong>Blood sample</strong><br>
                              A member of your health care team takes the sample by inserting a needle into a vein in your arm. For newborn screening tests, a blood sample is taken by pricking your baby's heel.</div>
                          </li>
                          <li><i class="fa fa-minus"></i>
                            <div class="ttm-list-li-content"><strong>Cheek swab</strong><br>
                              For some tests, a swab sample from the inside of your cheek is collected for genetic testing.</div>
                          </li>
                          <li><i class="fa fa-minus"></i>
                            <div class="ttm-list-li-content"><strong>Amniocentesis</strong><br>
                              In this prenatal genetic test, your doctor inserts a thin, hollow needle through your abdominal wall and into your uterus to collect a small amount of amniotic fluid for testing. </div>
                          </li>
                          <li><i class="fa fa-minus"></i>
                            <div class="ttm-list-li-content"><strong>Chorionic villus sampling</strong><br>
                              For this prenatal genetic test, your doctor takes a tissue sample from the placenta. Depending on your situation, the sample may be taken with a tube (catheter) through your cervix or through your abdominal wall and uterus using a thin needle.</div>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- toggle end -->
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- row end -->
    </div>
  </section>
  <!--technology-section end-->

  <section class="ttm-row procedure-section-2 ttm-bgcolor-grey bg-img9 ttm-bg ttm-bgimage-yes z-index_1 res-991-mt-0 clearfix" style="    background: #fff;">
    <div class="container">
      <!-- row -->
      <div class="row">
        <div class="col-lg-9 col-md-8 col-sm-9 m-auto">
          <!-- section-title -->
          <div class="section-title with-sep title-style-center_text">
            <div class="title-header">
              <h5>Genetic testing</h5>
              <h2 class="title">Results</h2>
            </div>
            <div class="title-desc">The amount of time it takes for you to receive your genetic test results depends on the type of test and your health care facility. Talk to your doctor, medical geneticist or genetic counselor before the test about when you can expect the results and have a discussion about them.</div>
          </div>
          <!-- section-title end -->
        </div>
      </div>
      <!-- row end -->
      <div class="row">
        <!-- row -->
        <div class="col-md-4">
          <!-- featured-imagebox -->
          <div class="featured-icon-box icon-align-top-content text-center style4">
            <div class="featured-icon">
              <div class="ttm-icon ttm-icon_element-fill ttm-icon_element-color-white ttm-icon_element-size-md ttm-icon_element-style-rounded"> <i class="flaticon-lab-2"></i> <span class="fea-number">01</span> </div>
            </div>
            <div class="featured-content">
              <div class="featured-title">
                <h5>Positive results</h5>
              </div>
              <div class="featured-desc">
                <p>If the genetic test result is positive, that means the genetic change that was being tested for was detected. The steps you take after you receive a positive result will depend on the reason you had genetic testing.</p>
              </div>
              <br>
              <a class="ttm-btn" href="results.php">Read More</a>
            </div>
            <div class="arrow"> <img src="images/arrow-1.png" alt=""> </div>
          </div>
          <!-- featured-imagebox end-->
        </div>
        <div class="col-md-4">
          <!-- featured-imagebox -->
          <div class="featured-icon-box icon-align-top-content text-center style4">
            <div class="featured-icon">
              <div class="ttm-icon ttm-icon_element-fill ttm-icon_element-color-white ttm-icon_element-size-md ttm-icon_element-style-rounded"> <i class="flaticon-healthcare-and-medical-1"></i> <span class="fea-number">02</span> </div>
            </div>
            <div class="featured-content">
              <div class="featured-title">
                <h5>Negative results</h5>
              </div>
              <div class="featured-desc">
                <p>A negative result means a mutated gene was not detected by the test, which can be reassuring, but it's not a 100 percent guarantee that you don't have the disorder. The accuracy of genetic tests to detect mutated genes varies, depending on the condition being tested for and whether or not the gene mutation was previously identified in a family member.</p>
                <br>
                <a class="ttm-btn" href="results.php">Read More</a>
              </div>
            </div>
            <div class="arrow flip-arrow"> <img src="images/arrow-1.png" alt=""> </div>
          </div>
          <!-- featured-imagebox end-->
        </div>
        <div class="col-md-4">
          <!-- featured-imagebox -->
          <div class="featured-icon-box icon-align-top-content text-center style4">
            <div class="featured-icon">
              <div class="ttm-icon ttm-icon_element-fill ttm-icon_element-color-white ttm-icon_element-size-md ttm-icon_element-style-rounded"> <i class="flaticon-laboratory-3"></i> <span class="fea-number">03</span> </div>
            </div>
            <div class="featured-content">
              <div class="featured-title">
                <h5>Inconclusive results</h5>
              </div>
              <div class="featured-desc">
                <p>In some cases, a genetic test may not provide helpful information about the gene in question. Everyone has variations in the way genes appear, and often these variations don't affect your health.</p>
                <br>
                <a class="ttm-btn" href="results.php">Read More</a>
              </div>
            </div>
          </div>
          <!-- featured-imagebox end-->
        </div>
      </div>
    </div>
  </section>

  <!--blog-section-->
  <section class="ttm-row clearfix" style="background: #f6faff">
    <div class="container">
      <!-- row -->
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="mt_110">
            <div class="ttm-col-bgcolor-yes ttm-bgcolor-white col-bg-img-fourteen ttm-col-bgimage-yes ttm-bg h-100" style="padding: 20px 30px;">
              <div class="ttm-col-wrapper-bg-layer ttm-bg-layer"> </div>
              <div class="layer-content">
                <div class="row align-items-center">
                  <div class="col-md-8 col-lg-9">
                    <div class="pr-80 border-right res-991-pr-30 res-991-mr_30">
                      <!-- section title -->
                      <div class="section-title mb-0">
                        <div class="title-header">
                          <h2 class="title">Genetic counseling</h2>
                        </div>
                        <div class="title-desc">No matter what the results of your genetic testing, talk with your doctor, medical geneticist or genetic counselor about questions or concerns you may have. This will help you understand what the results mean for you and your family.</div>
                      </div>
                      <!-- section title end -->
                    </div>
                  </div>
                  <div class="col-md-4 col-lg-3">
                    <div class="text-md-right res-991-pt-30">
                      <div class="mb-15 ttm-btn ttm-btn-size-md ttm-btn-shape-rounded ttm-btn-style-border ttm-icon-btn-left " href="#"> <i class="ti ti-headphone-alt"></i> +xxxxxxxxx</div>
                      <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-rounded buy-btn  ttm-btn-color-skincolor" href="contact.php">Get a Quote Now</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- row end -->
    </div>
  </section>

  <!--blog-section end-->

</div>
<!--site-main end-->
<?php include('includes/footer.php')
?>